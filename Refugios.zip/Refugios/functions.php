<?php
/**
 * Refugios — functions.php
 * Registers all theme functionality, assets, menus,
 * WooCommerce support and custom helpers.
 */

defined('ABSPATH') || exit;

/* =========================================================
 1. THEME SETUP
 ========================================================= */

function refugios_setup()
{
    load_theme_textdomain('refugios', get_template_directory() . '/languages');

    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('customize-selective-refresh-widgets');
    add_theme_support('html5', [
        'search-form', 'comment-form', 'comment-list',
        'gallery', 'caption', 'style', 'script',
    ]);
    add_theme_support('woocommerce', [
        'thumbnail_image_width' => 600,
        'gallery_thumbnail_image_width' => 150,
    ]);
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');

    add_image_size('refugios-hero', 1920, 900, true);
    add_image_size('refugios-book', 400, 600, true);
    add_image_size('refugios-blog', 800, 450, true);
    add_image_size('refugios-thumb', 400, 300, true);

    register_nav_menus([
        'primary' => esc_html__('Menú Principal', 'refugios'),
        'footer-1' => esc_html__('Footer — Tienda', 'refugios'),
        'footer-2' => esc_html__('Footer — Info', 'refugios'),
        'footer-3' => esc_html__('Footer — Legal', 'refugios'),
    ]);
}
add_action('after_setup_theme', 'refugios_setup');

/* =========================================================
 2. CONTENT WIDTH
 ========================================================= */

function refugios_content_width()
{
    $GLOBALS['content_width'] = apply_filters('refugios_content_width', 1320);
}
add_action('after_setup_theme', 'refugios_content_width', 0);

/* =========================================================
 3. ENQUEUE SCRIPTS & STYLES
 ========================================================= */

function refugios_enqueue_assets()
{

    /* ---- Tailwind CDN (no defer, in head) ---- */
    wp_enqueue_script(
        'tailwindcdn',
        'https://cdn.tailwindcss.com',
    [],
        null,
        false // in <head>
    );

    /* ---- Tailwind Config — injected BEFORE the CDN script ---- */
    $tailwind_config = "
window.tailwind = window.tailwind || {};
tailwind.config = {
    corePlugins: { preflight: false },
    theme: {
        extend: {
            colors: {
                cream:  '#f5e9e2',
                brown:  '#4e342e',
                amber:  '#d9a066',
                teal:   '#02535a',
            },
            fontFamily: {
                serif: ['Playfair Display', 'Georgia', 'serif'],
                sans:  ['Montserrat', 'Arial', 'sans-serif'],
                body:  ['Lato', 'sans-serif'],
            },
        },
    },
};";
    wp_add_inline_script('tailwindcdn', $tailwind_config, 'before');

    /* ---- Google Fonts ---- */
    wp_enqueue_style(
        'refugios-fonts',
        'https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,300;0,400;0,700;1,300;1,400&family=Montserrat:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400&family=Playfair+Display:ital,wght@0,400;0,600;0,700;0,800;1,400;1,700&display=swap',
    [],
        null
    );

    /* ---- Font Awesome 6 ---- */
    wp_enqueue_style(
        'font-awesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
    [],
        '6.5.1'
    );

    /* ---- Theme stylesheet ---- */
    wp_enqueue_style(
        'refugios-style',
        get_stylesheet_uri(),
    [],
        wp_get_theme()->get('Version')
    );

    /* ---- Main JS (footer) ---- */
    wp_enqueue_script(
        'refugios-main',
        get_template_directory_uri() . '/assets/js/main.js',
    [],
        wp_get_theme()->get('Version'),
        true // in footer
    );

    /* ---- Pass data to JS ---- */
    wp_localize_script('refugios-main', 'refugiosData', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('refugios_nonce'),
        'siteUrl' => home_url(),
        'cartUrl' => function_exists('wc_get_cart_url') ? wc_get_cart_url() : '',
        'shopUrl' => function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : '',
    ]);

    /* ---- WooCommerce: enqueue comment-reply if needed ---- */
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'refugios_enqueue_assets');

/* =========================================================
 3.1 PERFORMANCE OPTIMIZATIONS
 ========================================================= */

/**
 * Add async/defer to specific scripts for better performance.
 */
function refugios_script_loader_tag($tag, $handle, $src)
{
    // Scripts to defer
    $defer_scripts = ['tailwindcdn', 'refugios-main', 'wp-embed'];
    
    if (in_array($handle, $defer_scripts)) {
        return str_replace(' src', ' defer src', $tag);
    }

    // Scripts to load async
    $async_scripts = [];
    if (in_array($handle, $async_scripts)) {
        return str_replace(' src', ' async src', $tag);
    }

    return $tag;
}
add_filter('script_loader_tag', 'refugios_script_loader_tag', 10, 3);

/**
 * Add resource hints (preconnect) to headers.
 */
function refugios_resource_hints($urls, $relation_type)
{
    if ('preconnect' === $relation_type) {
        $urls[] = 'https://fonts.googleapis.com';
        $urls[] = 'https://fonts.gstatic.com';
        $urls[] = 'https://cdn.tailwindcss.com';
        $urls[] = 'https://cdnjs.cloudflare.com';
    }
    return $urls;
}
add_filter('wp_resource_hints', 'refugios_resource_hints', 10, 2);

/* =========================================================
 3.2 CLEANUP WORDPRESS BLOAT (PageSpeed Boost)
 ========================================================= */

function refugios_cleanup_wp_head()
{
    // Remove Emoji scripts and styles
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
    
    // Remove Gutenberg CSS from head if not needed elsewhere
    // wp_dequeue_style( 'wp-block-library' );
    // wp_dequeue_style( 'wp-block-library-theme' );
    // wp_dequeue_style( 'wc-block-style' ); 
    
    // Remove RSD, WLW, Shortlink and WP Generator
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'wp_shortlink_wp_head');
}
add_action('after_setup_theme', 'refugios_cleanup_wp_head');

/* =========================================================
 4. WIDGETS / SIDEBARS
 ========================================================= */

function refugios_widgets_init()
{
    $defaults = [
        'before_widget' => '<div class="blog-sidebar-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="blog-sidebar-widget__header">',
        'after_title' => '</h4><div class="blog-sidebar-widget__body">',
    ];

    register_sidebar(array_merge($defaults, [
        'name' => esc_html__('Sidebar Blog', 'refugios'),
        'id' => 'sidebar-blog',
        'description' => esc_html__('Widgets del sidebar del blog.', 'refugios'),
    ]));

    register_sidebar(array_merge($defaults, [
        'name' => esc_html__('Sidebar Tienda', 'refugios'),
        'id' => 'sidebar-shop',
        'description' => esc_html__('Widgets del sidebar de la tienda.', 'refugios'),
    ]));
}
add_action('widgets_init', 'refugios_widgets_init');

/* =========================================================
 5. WOOCOMMERCE
 ========================================================= */

// Remove default WooCommerce wrappers ONLY when WooCommerce is active
function refugios_woo_setup()
{
    remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
    remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
    remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);

    add_action('woocommerce_before_main_content', 'refugios_woo_wrapper_start', 10);
    add_action('woocommerce_after_main_content', 'refugios_woo_wrapper_end', 10);
}
add_action('woocommerce_loaded', 'refugios_woo_setup');

function refugios_woo_wrapper_start()
{
    echo '<div class="woo-main-wrapper container section-pad">';
}
function refugios_woo_wrapper_end()
{
    echo '</div>';
}

/* =========================================================
 6. BODY CLASSES
 ========================================================= */

function refugios_body_class($classes)
{
    if (is_front_page())
        $classes[] = 'is-front-page';
    if (is_singular())
        $classes[] = 'is-singular';
    // Guard WooCommerce-specific conditional tags
    if (function_exists('is_shop') && is_shop())
        $classes[] = 'is-shop';
    if (function_exists('is_woocommerce') && is_woocommerce())
        $classes[] = 'is-woocommerce';
    return $classes;
}
add_filter('body_class', 'refugios_body_class');

/* =========================================================
 7. CUSTOM EXCERPT LENGTH
 ========================================================= */

function refugios_excerpt_length($length)
{
    return 20;
}
add_filter('excerpt_length', 'refugios_excerpt_length');

function refugios_excerpt_more($more)
{
    return '&hellip;';
}
add_filter('excerpt_more', 'refugios_excerpt_more');

/* =========================================================
 8. HELPER FUNCTIONS
 ========================================================= */

/**
 * Display cart icon with item count.
 */
function refugios_cart_icon()
{
    if (!function_exists('WC'))
        return;
    $count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
    $url = function_exists('wc_get_cart_url') ? wc_get_cart_url() : '#';
?>
    <a href="<?php echo esc_url($url); ?>" class="nav-cart" aria-label="<?php esc_attr_e('Ver carrito', 'refugios'); ?>">
        <i class="fa-solid fa-bag-shopping" aria-hidden="true"></i>
        <?php if ($count > 0): ?>
            <span class="nav-cart-count" aria-label="<?php echo esc_attr(sprintf(__('%d artículos en el carrito', 'refugios'), $count)); ?>">
                <?php echo esc_html($count); ?>
            </span>
        <?php
    endif; ?>
    </a>
    <?php
}

/**
 * Update cart count via AJAX.
 */
function refugios_cart_count_ajax()
{
    if (!function_exists('WC'))
        wp_send_json_error();
    wp_send_json_success([
        'count' => WC()->cart->get_cart_contents_count(),
    ]);
}
add_action('wp_ajax_refugios_cart_count', 'refugios_cart_count_ajax');
add_action('wp_ajax_nopriv_refugios_cart_count', 'refugios_cart_count_ajax');

/**
 * Render a breadcrumb trail.
 */
function refugios_breadcrumb()
{
    $items = [];
    $home = '<a href="' . esc_url(home_url()) . '">' . esc_html__('Inicio', 'refugios') . '</a>';
    $items[] = $home;

    if (is_singular()) {
        if ($cats = get_the_category()) {
            $items[] = '<a href="' . esc_url(get_category_link($cats[0]->term_id)) . '">'
                . esc_html($cats[0]->name) . '</a>';
        }
        $items[] = '<span>' . esc_html(get_the_title()) . '</span>';
    }
    elseif (is_category()) {
        $items[] = '<span>' . esc_html(single_cat_title('', false)) . '</span>';
    }
    elseif (is_tag()) {
        $items[] = '<span>' . esc_html__('Etiqueta:', 'refugios') . ' ' . single_tag_title('', false) . '</span>';
    }
    elseif (is_search()) {
        $items[] = '<span>' . esc_html__('Búsqueda:', 'refugios') . ' ' . esc_html(get_search_query()) . '</span>';
    }
    elseif (function_exists('is_shop') && is_shop()) {
        $items[] = '<span>' . esc_html__('Tienda', 'refugios') . '</span>';
    }
    elseif (function_exists('is_product_category') && is_product_category()) {
        $page_title = function_exists('woocommerce_page_title') ? woocommerce_page_title(false) : get_the_archive_title();
        $items[] = '<span>' . esc_html($page_title) . '</span>';
    }
    elseif (is_archive()) {
        $items[] = '<span>' . esc_html(get_the_archive_title()) . '</span>';
    }
    elseif (is_page()) {
        $items[] = '<span>' . esc_html(get_the_title()) . '</span>';
    }

    $sep = '<span class="sep" aria-hidden="true">›</span>';
    echo '<nav class="page-header__breadcrumb" aria-label="' . esc_attr__('Ruta de navegación', 'refugios') . '">';
    echo implode(' ' . $sep . ' ', $items);
    echo '</nav>';
}

/**
 * Return post category as first item.
 */
function refugios_first_category($post_id = null)
{
    $post_id = $post_id ?: get_the_ID();
    $cats = get_the_category($post_id);
    return $cats ? esc_html($cats[0]->name) : '';
}

/**
 * WooCommerce: product category term name.
 */
function refugios_product_category($post_id = null)
{
    if (!function_exists('get_the_terms'))
        return '';
    $post_id = $post_id ?: get_the_ID();
    $terms = get_the_terms($post_id, 'product_cat');
    if ($terms && !is_wp_error($terms)) {
        return esc_html($terms[0]->name);
    }
    return '';
}

/**
 * WooCommerce: Get product author from multiple possible attributes.
 */
function refugios_get_product_author($product = null)
{
    if (!$product) {
        global $product;
    }
    if (!$product || !is_a($product, 'WC_Product')) {
        return '';
    }

    $author = '';
    // Slugs to check based on user input and common variations
    $author_slugs = [
        'pa_autor-a', 'autor-a', 'Autor (a)', 
        'pa_autor', 'autor', 
        'pa_author', 'author', 
        'pa_autores', 'autores'
    ];

    foreach ($author_slugs as $slug) {
        $attr_val = $product->get_attribute($slug);
        if (!empty($attr_val)) {
            $author = $attr_val;
            break;
        }
    }

    // Fallback: try to see if it's a tag
    if (empty($author)) {
        $tags = get_the_terms($product->get_id(), 'product_tag');
        if ($tags && !is_wp_error($tags)) {
            $author = $tags[0]->name;
        }
    }

    return $author ?: 'Autor desconocido';
}

/**
 * Display author on single product page summary.
 */
function refugios_display_single_product_author()
{
    $author = refugios_get_product_author();
    if ($author) {
        echo '<div class="refugios-single-author" style="font-family: var(--font-sans); font-weight: 600; text-transform: uppercase; color: var(--color-amber); margin-bottom: 0.5rem; font-size: 0.9rem;">' . esc_html($author) . '</div>';
    }
}
add_action('woocommerce_single_product_summary', 'refugios_display_single_product_author', 7);

/* =========================================================
 9. SECURITY & MISC
 ========================================================= */

// Remove WordPress version from head
remove_action('wp_head', 'wp_generator');

// XML-RPC off (unless specifically needed)
add_filter('xmlrpc_enabled', '__return_false');

/* =========================================================
 10. CUSTOMIZER — Brand Options
 ========================================================= */

function refugios_customize_register($wp_customize)
{

    // Panel
    $wp_customize->add_panel('refugios_panel', [
        'title' => esc_html__('Refugios — Opciones de Marca', 'refugios'),
        'priority' => 30,
    ]);

    // Section: Hero
    $wp_customize->add_section('refugios_hero', [
        'title' => esc_html__('Hero Section', 'refugios'),
        'panel' => 'refugios_panel',
    ]);

    $hero_fields = [
        'refugios_hero_label' => ['label' => 'Etiqueta Hero', 'default' => 'Librería & Cafetería Especializada'],
        'refugios_hero_title' => ['label' => 'Título Hero (H1)', 'default' => 'Donde los libros encuentran su café.'],
        'refugios_hero_subtitle' => ['label' => 'Subtítulo Hero', 'default' => 'Un espacio para pausar, leer y conectar. Libros curados y café de especialidad en un mismo refugio.'],
        'refugios_hero_cta_1' => ['label' => 'CTA Primario — Texto', 'default' => 'Explorar Libros'],
        'refugios_hero_cta_1_url' => ['label' => 'CTA Primario — URL', 'default' => '/tienda'],
        'refugios_hero_cta_2' => ['label' => 'CTA Secundario — Texto', 'default' => 'Ver el Menú'],
        'refugios_hero_cta_2_url' => ['label' => 'CTA Secundario — URL', 'default' => '/manifiestos'],
    ];

    foreach ($hero_fields as $id => $args) {
        $wp_customize->add_setting($id, [
            'default' => $args['default'],
            'sanitize_callback' => 'sanitize_text_field',
        ]);
        $wp_customize->add_control($id, [
            'label' => $args['label'],
            'section' => 'refugios_hero',
            'type' => 'text',
        ]);
    }

    // Hero image
    $wp_customize->add_setting('refugios_hero_image', ['default' => '']);
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'refugios_hero_image', [
        'label' => esc_html__('Imagen de fondo Hero', 'refugios'),
        'section' => 'refugios_hero',
    ]));

    // Section: Pausa (Café)
    $wp_customize->add_section('refugios_pausa', [
        'title' => esc_html__('Sección La Pausa (Café)', 'refugios'),
        'panel' => 'refugios_panel',
    ]);

    $pausa_fields = [
        'refugios_pausa_title' => ['label' => 'Título La Pausa', 'default' => 'El café que acompaña cada página.'],
        'refugios_pausa_desc' => ['label' => 'Descripción', 'default' => 'En Refugios creemos que cada buen libro merece una buena taza. Seleccionamos cuidadosamente nuestros granos y nuestras historias.'],
        'refugios_pausa_stat1_num' => ['label' => 'Stat 1 — Número', 'default' => '200+'],
        'refugios_pausa_stat1_label' => ['label' => 'Stat 1 — Etiqueta', 'default' => 'Títulos'],
        'refugios_pausa_stat2_num' => ['label' => 'Stat 2 — Número', 'default' => '12'],
        'refugios_pausa_stat2_label' => ['label' => 'Stat 2 — Etiqueta', 'default' => 'Orígenes café'],
        'refugios_pausa_stat3_num' => ['label' => 'Stat 3 — Número', 'default' => '6'],
        'refugios_pausa_stat3_label' => ['label' => 'Stat 3 — Etiqueta', 'default' => 'Años'],
    ];

    foreach ($pausa_fields as $id => $args) {
        $wp_customize->add_setting($id, [
            'default' => $args['default'],
            'sanitize_callback' => 'sanitize_text_field',
        ]);
        $wp_customize->add_control($id, [
            'label' => $args['label'],
            'section' => 'refugios_pausa',
            'type' => 'text',
        ]);
    }

    $wp_customize->add_setting('refugios_pausa_image', ['default' => '']);
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'refugios_pausa_image', [
        'label' => esc_html__('Imagen taza de café', 'refugios'),
        'section' => 'refugios_pausa',
    ]));

    // Section: Contact
    $wp_customize->add_section('refugios_contact', [
        'title' => esc_html__('Datos de Contacto', 'refugios'),
        'panel' => 'refugios_panel',
    ]);

    $contact_fields = [
        'refugios_address' => ['label' => 'Dirección', 'default' => 'Calle de los Libros 42, Ciudad'],
        'refugios_hours' => ['label' => 'Horario', 'default' => 'Lun–Vie: 8:00–20:00 / Sáb–Dom: 9:00–21:00'],
        'refugios_phone' => ['label' => 'Teléfono / WhatsApp', 'default' => '+1 (555) 123-4567'],
        'refugios_email' => ['label' => 'Email', 'default' => 'hola@refugios.com'],
        'refugios_instagram' => ['label' => 'Instagram URL', 'default' => 'https://instagram.com/refugios'],
        'refugios_facebook' => ['label' => 'Facebook URL', 'default' => 'https://facebook.com/refugios'],
        'refugios_whatsapp' => ['label' => 'WhatsApp URL', 'default' => 'https://wa.me/15551234567'],
    ];

    foreach ($contact_fields as $id => $args) {
        $wp_customize->add_setting($id, [
            'default' => $args['default'],
            'sanitize_callback' => 'sanitize_text_field',
        ]);
        $wp_customize->add_control($id, [
            'label' => $args['label'],
            'section' => 'refugios_contact',
            'type' => 'text',
        ]);
    }
}
add_action('customize_register', 'refugios_customize_register');

/* =========================================================
 11. MENU FALLBACK FUNCTIONS
 (Called by wp_nav_menu as fallback_cb)
 ========================================================= */

/**
 * Fallback primary menu — renders all published pages.
 */
function refugios_fallback_menu()
{
    $pages = get_pages(['sort_column' => 'menu_order']);
    if (!$pages)
        return;
    echo '<ul id="primary-menu">';
    foreach ($pages as $page) {
        $current = (get_queried_object_id() === $page->ID) ? ' class="current-menu-item"' : '';
        printf(
            '<li%s><a href="%s">%s</a></li>',
            $current,
            esc_url(get_permalink($page->ID)),
            esc_html($page->post_title)
        );
    }
    echo '</ul>';
}

/**
 * Fallback footer store menu.
 */
function refugios_footer_fallback()
{
    $pages = [
        __('Tienda Refugios', 'refugios') => '/tienda-refugios',
        __('Blog', 'refugios') => '/blog',
        __('Quiénes Somos', 'refugios') => '/quienes-somos',
        __('Contacto', 'refugios') => '/contacto',
    ];
    echo '<ul class="footer-links">';
    foreach ($pages as $label => $slug) {
        printf(
            '<li><a href="%s">%s</a></li>',
            esc_url(home_url($slug)),
            esc_html($label)
        );
    }
    echo '</ul>';
}

/**
 * Fallback footer legal menu.
 */
function refugios_footer_legal_fallback()
{
    $pages = [
        __('Términos y Condiciones', 'refugios') => '/terminos-y-condiciones',
        __('Preguntas Frecuentes', 'refugios') => '/preguntas-frecuentes',
    ];
    echo '<ul class="footer-legal-links">';
    foreach ($pages as $label => $slug) {
        printf(
            '<li><a href="%s">%s</a></li>',
            esc_url(home_url($slug)),
            esc_html($label)
        );
    }
    echo '</ul>';
}
